package example

/*
网络需要支持：
   1. 框架支持KCP基础帧同步模型
   2. 网络通信兼容protobuf数据格式
   3. 同时有开关可以确定是是否支持TCP模式

服务器渲染数据操作：
*/